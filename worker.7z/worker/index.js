const azureStorage = require("azure-storage");
const connectionString =
  "DefaultEndpointsProtocol=https;AccountName=ambrosiaalertstorage;AccountKey=rwWTRwFJgtuSVOJikQMJUfyIFFKL172jcVYDS99AIHcO3KIFxNYaPKUAfCUqJqUfnNMwR+neA58a+ASt720Rzw==;EndpointSuffix=core.windows.net";
const tableService = azureStorage.createTableService(connectionString);
const tableNameUsers = "users";
const tableNameRiskZones = "ambrosiatable";
const queueName = "messsages";

// Funcție pentru a obține utilizatorii din tabela 'users'
async function getUsers() {
  return new Promise((resolve, reject) => {
    const query = new azureStorage.TableQuery();
    tableService.queryEntities(
      tableNameUsers,
      query,
      null,
      (error, result, response) => {
        if (!error) {
          const users = result.entries;
          resolve(users);
        } else {
          reject(error);
        }
      }
    );
  });
}

// Funcție pentru a obține zonele de risc din tabela 'ambrosiatable'
async function getRiskZones() {
  return new Promise((resolve, reject) => {
    const query = new azureStorage.TableQuery();
    tableService.queryEntities(
      tableNameRiskZones,
      query,
      null,
      (error, result, response) => {
        if (!error) {
          const riskZones = result.entries;
          resolve(riskZones);
        } else {
          reject(error);
        }
      }
    );
  });
}

// Funcție pentru a calcula distanța între două puncte cu coordonate longitudine și latitudine
function calculateDistance(lat1, lon1, lat2, lon2) {
  // Convertirea coordonatelor din grade în radiani
  const radianLat1 = toRadians(lat1);
  const radianLon1 = toRadians(lon1);
  const radianLat2 = toRadians(lat2);
  const radianLon2 = toRadians(lon2);

  // Diferența dintre latitudine și longitudine
  const deltaLat = radianLat2 - radianLat1;
  const deltaLon = radianLon2 - radianLon1;

  // Formula Haversine pentru calcularea distanței
  const a =
    Math.sin(deltaLat / 2) ** 2 +
    Math.cos(radianLat1) * Math.cos(radianLat2) * Math.sin(deltaLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  // Raza Pământului în kilometri (sau mile)
  const radiusOfEarth = 6371; // Raza în kilometri

  // Calcularea distanței
  const distance = radiusOfEarth * c;

  return distance;
}

function toRadians(degrees) {
  return degrees * (Math.PI / 180);
}

// Parametru pentru distanța minimă pentru a declanșa notificarea
const thresholdDistance = 500; // Specificați distanța minimă în funcție de unitatea de măsură folosită

const { QueueServiceClient } = require("@azure/storage-queue");

// Funcție pentru adăugarea unui mesaj în coada de notificări
async function addToNotificationQueue(userId, zoneId) {
  const queueServiceClient =
    QueueServiceClient.fromConnectionString(connectionString);
  const queueClient = queueServiceClient.getQueueClient(queueName);

  const message = {
    body: JSON.stringify({ userId, zoneId }),
    messageText: "Attention! You are in a high-risk allergy zone.", // Mesajul în limba engleză
    // alte proprietăți opționale ale mesajului pot fi adăugate aici
  };

  await queueClient.sendMessage(JSON.stringify(message));
  console.log(
    `Mesaj adăugat în coada de notificări pentru utilizatorul ${userId} și zona ${zoneId}.`
  );
}

// Funcție principală pentru procesarea distanței și trimiterea notificărilor
async function processDistanceAndNotifications() {
  try {
    const users = await getUsers();
    const riskZones = await getRiskZones();

    for (const user of users) {
      for (const zone of riskZones) {
        const distance = calculateDistance(
          user.latitude,
          user.longitude,
          zone.latitude,
          zone.longitude
        );
        if (distance < thresholdDistance) {
          await addToNotificationQueue(user.Name, "balta");
        }
      }
    }

    console.log("Distanțe calculate și notificări adăugate cu succes.");
  } catch (error) {
    console.error(
      "Eroare în procesul de calculare distanță și adăugare notificări:",
      error
    );
  }
}

// Apelați funcția principală pentru a începe procesul
processDistanceAndNotifications();
